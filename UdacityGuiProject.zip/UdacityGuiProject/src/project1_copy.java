//problems i have :
//cant get the ui right
//dont know how to access table columns and rows to get their data : try get Invsdata
//how to properly align csv data into the invoice table?

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

public class project1_copy extends JFrame implements ActionListener {

    private JTable InvsTable; //create table
    private JTable InvItemsTable;

    private  String[] InvsTablecols = { "No.", "Date" , "Customer" , "Total" }; //table col names
    private String[][] Invsdata  /*new String[3][4]*/; //tables data
    private String[][] InvsItemsdata/* = new String[3][4]*/;

    private  String[] InvsItemsTablecols = { "No.", "Item Name" , "Item Price" , "Count" ," Item Total" };

    private JButton Create;
    private JButton Delete;
    private JButton Save;
    private JButton Cancel;
    private JLabel InvNo;
    private JLabel InvVal;
    private JLabel InvDate;
    private JLabel CustName;
    private JLabel InvTotal;
    private JLabel InvTotalVal;
    private JTextField InvDt_txt;
    private JTextField CusName_txt;
    private JSplitPane testDP;
    private JMenuBar menuBar;
    private JMenuItem LoadFile;
    private JMenuItem SaveFile;
    private JMenu File;

    private JPanel right;
    private JPanel left;
    private JPanel tableright;
    private JPanel input;
    private JPanel tableleft;
    //buttons are inside the two frames

    public project1_copy(){
        super("Sales invoice generator");
        setSize(700,500);
        setLocation(200,200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);


        menuBar = new JMenuBar();
        File = new JMenu("File");
        LoadFile = new JMenuItem("Load file",'l');
        SaveFile = new JMenuItem("Save file" , 's');
        SaveFile.setAccelerator(KeyStroke.getKeyStroke('S', KeyEvent.CTRL_DOWN_MASK));
        testDP = new JSplitPane();
        InvNo = new JLabel("Invoice Number ");
        InvDate = new JLabel("Invoice Date ");
        CustName = new JLabel("Customer Name ");
        InvTotal = new JLabel("Invoice Total ");
        InvVal = new JLabel("23");
        InvTotalVal = new JLabel("350.0");
        InvDt_txt = new JTextField(20);
        CusName_txt = new JTextField(20);
        Create = new JButton("Create new Invoice");
        Delete = new JButton("Delete Invoice");
        Save = new JButton("Save");
        Cancel = new JButton("Cancel");

        InvsTable = new JTable(Invsdata,InvsTablecols);
        InvItemsTable = new JTable(InvsItemsdata,InvsItemsTablecols);

          right = new JPanel();
          right.setVisible(true);
        right.setSize(350,500);

        left = new JPanel();
          left.setVisible(true);
          left.setSize(350,500);
          //left.setAlignmentX(10);
          tableright = new JPanel();
          tableright.setVisible(true);
          input = new JPanel();
          input.setVisible(true);
        input.setSize(350,100);
          tableleft = new JPanel();
          tableleft.setVisible(true);

        setJMenuBar(menuBar); //adds the menu bar to the panel
        menuBar.add(File);
        File.add(LoadFile);
        File.add(SaveFile);

        setLayout(new FlowLayout());
//        testDP.setSize(350,500);
//        add(testDP);
        tableleft.add(new JScrollPane(InvsTable));
        tableright.add(new JScrollPane(InvItemsTable));
        left.add(Create);
        left.add(Delete);
        right.add(Save);
        right.add(Cancel);
        input.add(InvDate);
        input.add(InvDt_txt);
       // input.add(CustName);
        input.add(CusName_txt);
       // input.add(InvNo);
        input.add(InvVal);
        input.add(InvTotalVal);


        input.setLayout(new BoxLayout(input,BoxLayout.Y_AXIS));

        right.add(input);
        right.add(tableright);
    //    right.setLayout(new BoxLayout(right,BoxLayout.Y_AXIS));
//
//        left.add(Create);
//        left.add(Delete);
//        right.add(Save);
//        right.add(Cancel);

        left.add(tableleft);
       // left.setLayout(new BoxLayout(left,BoxLayout.Y_AXIS));



        add(left);
        add(right);
//        setJMenuBar(menuBar);
//        menuBar.add(File);
//        File.add(LoadFile);
//        File.add(SaveFile);
//        add(menuBar);

        Create.addActionListener(this);
        Delete.addActionListener(this);
        Save.addActionListener(this);
        Cancel.addActionListener(this);

        Create.setActionCommand("Cr");
        Delete.setActionCommand("D");
        Save.setActionCommand("S");
        Cancel.setActionCommand("Cx");
    }
    public static void main(String[] args) {
        new project1_copy().setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        int invnom = 1;
        switch (e.getActionCommand()){

            case "Cr":
                //if user clicks on create then the invnom value is increased by 1 and assigned to invoince number
//should create a new invoice by automatically increasing invoice number and providing it to the label InvVal
//and blanks the entry screen on the right except for the number
                break;

            case "D":
                InvDt_txt.setText("");
                CusName_txt.setText("");
                InvVal.setText("0");
                InvTotalVal.setText("0");
//should delete selected row from the Invstable
                break;

            case "S":
                //doesnt work for some reason
                String invDate = InvDt_txt.getText();
                String Name = CusName_txt.getText();
                String invoiceNo = InvVal.getText();
                String total = InvTotalVal.getText();
                Invsdata= new String[][]{{invoiceNo},{invDate}, {Name},{total}};
                //add variables into table Invstable
                break;

            case "Cx": //ths one is done
                 InvDt_txt.setText(null);
                 CusName_txt.setText(null);
                 InvVal.setText(null);
                break;
            }
    }
}
