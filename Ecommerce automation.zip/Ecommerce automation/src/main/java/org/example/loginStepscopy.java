package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class loginStepscopy {
    WebDriver driver ;


    public loginStepscopy(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver,this);
    }
    public void openAndNavigate() {
        System.setProperty("webdriver.chrome.driver","C:\\Users\\Kimo\\Downloads\\chromedriver_win32\\chromedriver.exe");
       // driver = new ChromeDriver();
        driver.navigate().to("https://www.amazon.eg/-/en/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.eg%2F%3F%26tag%3Degtxabkgode-21%26ref%3Dnav_ya_signin%26adgrpid%3D123528178741%26hvpone%3D%26hvptwo%3D%26hvadid%3D593152336207%26hvpos%3D%26hvnetw%3Dg%26hvrand%3D9796602087189701647%26hvqmt%3De%26hvdev%3Dc%26hvdvcmdl%3D%26hvlocint%3D%26hvlocphy%3D1005386%26hvtargid%3Dkwd-10573980%26hydadcr%3D334_2589534%26gclid%3DEAIaIQobChMIsO7-39j5-wIVxuzVCh0eLwXxEAAYASAAEgKLj_D_BwE%26language%3Den_AE&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=egflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&");
        driver.manage().window().maximize();
    }

    public void user_email(String UE){
        driver.findElement(By.id("ap_email")).sendKeys(UE);
        driver.findElement(By.id("continue")).click();
    }

    public void password(String pswrd){
        driver.findElement(By.id("ap_password")).sendKeys(pswrd);
        driver.findElement(By.name("ap_password")).sendKeys(Keys.ENTER);
    }

    public void search_for_bag(){
        driver.findElement(By.id("twotabsearchtextbox")).sendKeys("bag");
        driver.findElement(By.id("twotabsearchtextbox")).sendKeys(Keys.ENTER);
    }

    public void shop(){
        driver.findElement(By.cssSelector("img[class=\"s-image\"]")).click();
        driver.findElement(By.id("add-to-cart-button")).click();
    }
    public void shoppingCart(){
       String ActualRes=driver.findElement(By.cssSelector("span[class=\"a-size-medium-plus a-color-base sw-atc-text a-text-bold\"]")).getText();
    }
    public void deleteItem(){
        driver.findElement(By.id("sw-gtc_CONTENT")).click();
        driver.findElement(By.cssSelector("input[name=\"submit.delete.C940d772e-e614-43a5-9425-d89fa3001b69\"]")).click();
        String deleting_mssg = "OZUKO 9338 Waterproof Leather Crossbody Bag For Travel - Grey was removed from Shopping Cart";
        String actualmssg = driver.findElement(By.linkText("https://www.amazon.eg/-/en/gp/product/B09KQ6FFMY/ref=ox_sc_act_title_delete_1?smid=A1ZVRGNO5AYLOV&psc=1")).getText();
        // error maybe testng doesnt work
        // Assert.assertEquals(deleting_mssg,actualmssg);
    }


}
